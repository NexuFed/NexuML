"""Measure the existing direct native references without changing the learner."""

import json
from pathlib import Path
from resource import RUSAGE_SELF, getrusage
import sys
from time import perf_counter

import torch
from lightning.pytorch import Callback

from isaaclab_marl_config import short_horizon
from nexuml.training.lightning import NexuSession
from nexuml_library.environments.isaaclab import isaac_task_config
from nexuml_library.scenarios.reinforcement.isaaclab import (
    isaac_cartpole_ppo,
    isaac_so101_joint_reach_ppo,
)
from nexuml_library.scenarios.reinforcement.isaaclab_marl import isaac_pendulum_ippo


def now():
    torch.cuda.synchronize()
    return perf_counter()


class Timing(Callback):
    def __init__(self):
        self.batches = []

    def on_train_start(self, trainer, pl_module):
        self.start = self.previous = now()

    def on_train_batch_start(self, trainer, pl_module, batch, batch_idx):
        self.update_start = now()

    def on_train_batch_end(self, trainer, pl_module, outputs, batch, batch_idx):
        end = now()
        self.batches.append(
            [batch.batch_size.numel(), self.update_start - self.previous, end - self.update_start]
        )
        self.previous = end


name, output = sys.argv[1:]
output = Path(output)
started = perf_counter()
factory, frames, width, per_batch, minibatch = {
    "cartpole": (isaac_cartpole_ppo, 256, 8, 128, 64),
    "so101": (isaac_so101_joint_reach_ppo, 256, 8, 128, 64),
    "pendulum-ippo": (isaac_pendulum_ippo, 64, 2, 16, 16),
}[name]
scenario = factory(total_frames=frames, frames_per_batch=per_batch, num_envs=width)
if name == "pendulum-ippo":
    scenario.interaction.environment = scenario.interaction.environment.model_copy(
        update={"task_config": isaac_task_config(short_horizon)}
    )
scenario.training.algorithm = scenario.training.algorithm.model_copy(
    update={"update_epochs": 1, "minibatch_size": minibatch}
)
session = NexuSession(scenario, log_dir=output, enable_loggers=False, enable_progress_bar=False)
timing = Timing()
session.trainer.callbacks.append(timing)
with scenario.interaction.environment.job_scope():
    session.run()
    fitted = now()
    module = session.lightning_module
    assert int(module.frames) == sum(row[0] for row in timing.batches) == frames
    assert int(module.algorithm.updates) == frames // minibatch
    assert len(timing.batches) == frames // per_batch
    (output / "timing.json").write_text(
        json.dumps(
            {
                "scenario": name,
                "seed": scenario.training.seed,
                "width": width,
                "frames": int(module.frames),
                "minibatch_updates": int(module.algorithm.updates),
                "batches_frames_collect_s_update_s": timing.batches,
                "startup_s": timing.start - started,
                "fit_tail_s": fitted - timing.previous,
                "peak_rss_kib": getrusage(RUSAGE_SELF).ru_maxrss,
                "peak_torch_reserved_bytes": torch.cuda.max_memory_reserved(),
            },
            indent=2,
            allow_nan=False,
        )
        + "\n"
    )
